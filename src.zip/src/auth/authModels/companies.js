"use strict";
const {
    authenticateToken,
    authenticateBasic,
} = require("../../utils/authUsers");
const companies = (sequelize, DataTypes) => {
    const model = sequelize.define("companies", {
        name: {
            type: DataTypes.STRING,
            required: true,
        },
        numberOfEmployes: {
            type: DataTypes.STRING,
            required: true,
        },
        rating: {
            type: DataTypes.INTEGER,
            required: true,
        },
        email: {
            type: DataTypes.STRING,
            required: true,
            primaryKey: true,
        },
        phoneNumber: {
            type: DataTypes.INTEGER,
            required: true,
        },
        alt: {
            type: DataTypes.STRING,
            required: true,
        },
        long: {
            type: DataTypes.STRING,
            required: true,
        },

        description: {
            type: DataTypes.STRING,
            required: false,
            default: "",
        },
        capabilities: {
            type: DataTypes.VIRTUAL,
            get() {
                const acl = {
                    user: ["read", "create", "update", "delete"],
                    vistor: ["read"],
                };
                return acl[this.role];
            },
        },
    });
    model.authenticateBasic = authenticateBasic;
    model.authenticateToken = authenticateToken;

    model.auth = async function (email, hashedPassword) {
        try {
            let userD = await this.findOne({ where: { email: email } });
            if (userD) {
                let valid = await bcrypt.compare(
                    hashedPassword,
                    userD.password
                );
                if (valid) {
                    let newToken = jwt.sign({ email: userD.email }, secret);
                    userD.token = newToken;
                    return userD;
                } else {
                    return "wrong password!";
                }
            } else {
                return "invalid user!";
            }
        } catch (err) {
            return err;
        }
    };
    return model;
};
module.exports = companies;
