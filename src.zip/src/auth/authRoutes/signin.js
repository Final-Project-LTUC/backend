"use strict";
const express = require("express");
const base64 = require("base-64");
const router = express.Router();
const { companies, handymen, users } = require("../../models/index.js");

router.post("/signin", signIn);

async function signIn(req, res) {
    if (req.headers["authorization"]) {
        try {
            let base = req.headers.authorization.split(" ");
            let userpassEncoded = base.pop();
            let userpassDecoded = base64.decode(userpassEncoded).split(":");
            let [email, password] = userpassDecoded;
            let userD = await users.findOne({ where: { email: email } });
            console.log({ userD });
            if (userD) {
                if (userD.role == "company") {
                    companies
                        .auth(email, password)
                        .then((result) => {
                            try {
                                delete result.dataValues.password;
                                result.dataValues.role = "company";
                                res.send(result.dataValues);
                            } catch (err) {
                                res.send("Wrong Password");
                            }
                        })
                        .catch((err) => {
                            throw err;
                        });
                } else if (userD.role == "handyman") {
                    handymen
                        .auth(email, password)
                        .then((result) => {
                            try {
                                delete result.dataValues.password;
                                result.dataValues.role = "handyman";
                                res.send(result.dataValues);
                            } catch (err) {
                                res.send("Wrong Password");
                            }
                        })
                        .catch((err) => {
                            throw err;
                        });
                } else if (userD.role == "user") {
                    users
                        .auth(email, password)
                        .then((result) => {
                            try {
                                delete result.dataValues.password;
                                result.dataValues.role = "user";
                                res.send(result.dataValues);
                            } catch (err) {
                                res.send("Wrong Password");
                            }
                        })
                        .catch((err) => {
                            throw err;
                        });
                } else {
                    console.log("ERROR");
                }
            } else {
                res.send("User not found!");
            }
        } catch (err) {
            console.log(err);
            res.json(err);
        }
    } else {
        res.send("Headers Error!");
    }
}

module.exports = router;
